package com.dedyalwi.crud_api_dedyalwi

class ResultStatus {
    val pesan : String? = null
    val status : Int? = null
}
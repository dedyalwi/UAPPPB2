package com.dedyalwi.crud_api_dedyalwi

import com.google.gson.annotations.SerializedName
import java.io.Serializable
class DataItem : Serializable{
    @field:SerializedName("staff_name")
    val staffName: String? = null

    @field:SerializedName("staff_id")
    val staffId: String? = null
    @field:SerializedName("staff_jenkel")
    val staffJenkel: String? = null
    @field:SerializedName("staff_jurusan")
    val staffJurusan: String? = null
    @field:SerializedName("staff_hp")
    val staffHp: String? = null
    @field:SerializedName("staff_alamat")
    val staffAlamat: String? = null
}